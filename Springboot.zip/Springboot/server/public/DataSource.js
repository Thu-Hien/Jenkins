"use strict";
const sqlite3_1 = require("sqlite3");
class DataSource {
    constructor() {
        this.createQuestionTable = "CREATE TABLE TB_QUESTIONS (" +
            "id integer primary key, " +
            "question TEXT, " +
            "answerA TEXT, " +
            "answerB TEXT, " +
            "answerC TEXT, " +
            "answerD TEXT, " +
            "correctAnswer INT, " +
            "explanation TEXTnode " +
            ");";
        this.insertQ1 = "INSERT INTO TB_QUESTIONS VALUES (NULL, 'In which town are you taken by GNR?', 'Sin City', 'Salt Lake City', 'Paradise City', 'Munich City', 3, 'blabla')";
        this.insertQ2 = "INSERT INTO TB_QUESTIONS VALUES (NULL, 'Which song is not from AC/DC?', 'TNT', 'Highway to Hell', 'For Those About to Rock', 'Livin On a Prayer', 4, 'blabal')";
        this.insertQ3 = "INSERT INTO TB_QUESTIONS VALUES (NULL, 'Was ist meine Liebingsfarbe?', 'Rot', 'Gruen', 'Lila', 'Gelb', 2, 'blabla')";
        this.createUserTable = "CREATE TABLE TB_USERS (" +
            "id integer primary key, " +
            "user TEXT, " +
            "userCategory TEXT " +
            ");";
        this.insertU1 = "INSERT INTO TB_USERS VALUES (NULL, 'Emil', 'Lerner')";
        this.insertU2 = "INSERT INTO TB_USERS VALUES (NULL, 'Timo', 'Lehrer')";
        if (DataSource._instance) {
            throw new Error("Not available for singletons!");
        }
        DataSource._instance = this;
        this._db = new sqlite3_1.Database(':memory:');
    }
    static getInstance() {
        return DataSource._instance;
    }
    getDatabase() {
        return this._db;
    }
    initDatabase() {
        var db = this._db;
        var tableQuestion = this.createQuestionTable;
        var q1 = this.insertQ1;
        var q2 = this.insertQ2;
        var q3 = this.insertQ3;
        var tableUser = this.createUserTable;
        var u1 = this.insertU1;
        var u2 = this.insertU2;
        db.serialize(function () {
            db.run(tableQuestion);
            db.run(q1);
            db.run(q2);
            db.run(q3);
            db.run(tableUser);
            db.run(u1);
            db.run(u2);
        });
    }
}
exports.DataSource = DataSource;
DataSource._instance = new DataSource();
