"use strict";
const DataSource_1 = require("./DataSource");
const Question_1 = require("./Question");
class QuestionDAO {
    static getAllQuestions() {
        var query = "SELECT * FROM TB_QUESTIONS";
        return new Promise(function (resolve, reject) {
            QuestionDAO.ds.getDatabase().all(query, function (err, rows) {
                if (err) {
                    console.log("Failed");
                    reject(err);
                }
                else {
                    console.log("Success", rows);
                    var questions = new Array();
                    for (var row of rows) {
                        var question = new Question_1.Question(row['id'], row['question'], row['answerA'], row['answerB'], row['answerC'], row['answerD'], row['correctAnswer'], row['explanation']);
                        questions.push(question);
                    }
                    resolve(questions);
                }
            });
        });
    }
    static createQuestion(newQuestion) {
        var insert = "INSERT INTO TB_QUESTIONS VALUES (NULL, '" + newQuestion.getQuestion
            + "', '" + newQuestion.getAnswerA
            + "', '" + newQuestion.getAnswerB
            + "', '" + newQuestion.getAnswerC
            + "', '" + newQuestion.getAnswerD
            + "', '" + newQuestion.getCorrectAnswer
            + "', '" + newQuestion.getExplanation +
            "')";
        console.log(insert);
        return new Promise(function (resolve, reject) {
            QuestionDAO.ds.getDatabase().run(insert, function (err) {
                if (err) {
                    console.log("Failed");
                    reject(err);
                }
                else {
                    console.log("Success " + this.lastID);
                    resolve(this.lastID);
                }
            });
        });
    }
    static deleteQuestion(id) {
        var query = "DELETE FROM TB_QUESTIONS WHERE id='" + id + "'";
        return new Promise(function (resolve, reject) {
            QuestionDAO.ds.getDatabase().run(query, function (err) {
                if (err) {
                    console.log("Failed");
                    reject(err);
                }
                else {
                    console.log("Success" + id);
                    resolve(id);
                }
            });
        });
    }
    static getQuestionById(id, callback) {
        var query = "SELECT * FROM TB_QUESTIONS WHERE id='" + id + "'";
        this.ds.getDatabase().get(query, function (err, row) {
            var question = new Question_1.Question(row['id'], row['question'], row['answerA'], row['answerB'], row['answerC'], row['answerD'], row['correctAnswer'], row['explanation']);
            callback(question);
        });
    }
}
exports.QuestionDAO = QuestionDAO;
QuestionDAO.ds = DataSource_1.DataSource.getInstance();
