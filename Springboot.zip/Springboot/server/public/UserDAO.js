"use strict";
const DataSource_1 = require("./DataSource");
const User_1 = require("./User");
class UserDAO {
    static getAllUsers() {
        var queryUsers = "SELECT * FROM TB_USERS";
        return new Promise(function (resolve, reject) {
            UserDAO.ds.getDatabase().all(queryUsers, function (err, rows) {
                if (err) {
                    console.log("Failed");
                    reject(err);
                }
                else {
                    console.log("Success", rows);
                    var users = new Array();
                    for (var row of rows) {
                        var user = new User_1.User(row['id'], row['user'], row['userCategory']);
                        users.push(user);
                    }
                    resolve(users);
                }
            });
        });
    }
    static createUser(newUser) {
        var insert = "INSERT INTO TB_USERS VALUES (NULL, '" + newUser.getUser
            + "', '" + newUser.getUserCategory + "')";
        console.log(insert);
        return new Promise(function (resolve, reject) {
            UserDAO.ds.getDatabase().run(insert, function (err) {
                if (err) {
                    console.log("Failed");
                    reject(err);
                }
                else {
                    console.log("Success " + this.lastID);
                    resolve(this.lastID);
                }
            });
        });
    }
}
exports.UserDAO = UserDAO;
UserDAO.ds = DataSource_1.DataSource.getInstance();
