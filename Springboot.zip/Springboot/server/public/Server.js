"use strict";
const express = require("express");
const bodyParser = require("body-parser");
const Question_1 = require("./Question");
const DataSource_1 = require("./DataSource");
const QuestionDAO_1 = require("./QuestionDAO");
const User_1 = require("./User");
const UserDAO_1 = require("./UserDAO");
const app = express();
const port = process.env.PORT || 8080;
const router = express.Router();
var allowCrossDomain = function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
};
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(allowCrossDomain);
app.use('/hps', router);
app.listen(port);
console.log('http://127.0.0.1:' + port + '/hps');
DataSource_1.DataSource.getInstance().initDatabase();
router.get('/', function (req, res) {
    res.json({ "message": 'HPS server is running ...' });
});
router.get('/question/:id', function (req, res) {
    var id = req.params.id;
    var callback = function (question) {
        var response = JSON.stringify(question);
        res.json(JSON.parse(response));
    };
    QuestionDAO_1.QuestionDAO.getQuestionById(id, callback);
});
router.put('/question/create', function (req, res) {
    var jsonQuestion = JSON.parse(JSON.stringify(req.body));
    var question = new Question_1.Question(jsonQuestion['id'], jsonQuestion['question'], jsonQuestion['answerA'], jsonQuestion['answerB'], jsonQuestion['answerC'], jsonQuestion['answerD'], jsonQuestion['correctAnswer'], jsonQuestion['explanation']);
    QuestionDAO_1.QuestionDAO.createQuestion(question).then((resolve) => {
        res.json(JSON.parse(resolve.toString()));
    });
});
router.delete('/question/delete/:id', function (req, res) {
    var id = req.params.id;
    QuestionDAO_1.QuestionDAO.deleteQuestion(id).then((resolve) => {
        res.json(JSON.parse(resolve.toString()));
    });
});
router.get('/listQuestions', function (req, res) {
    QuestionDAO_1.QuestionDAO.getAllQuestions().then((resolve) => {
        res.json(JSON.parse(JSON.stringify(resolve)));
    });
});
router.get('/listUsers', function (req, res) {
    UserDAO_1.UserDAO.getAllUsers().then((resolve) => {
        res.json(JSON.parse(JSON.stringify(resolve)));
    });
});
router.put('/user/create', function (req, res) {
    var jsonUser = JSON.parse(JSON.stringify(req.body));
    var user = new User_1.User(jsonUser['id'], jsonUser['user'], jsonUser['userCategory']);
    UserDAO_1.UserDAO.createUser(user).then((resolve) => {
        res.json(JSON.parse(resolve.toString()));
    });
});
