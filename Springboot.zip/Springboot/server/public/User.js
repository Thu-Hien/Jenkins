"use strict";
class User {
    constructor(id, user, userCategory) {
        this.id = id;
        this.user = user;
        this.userCategory = userCategory;
    }
    get getUser() {
        return this.user;
    }
    get getId() {
        return this.id;
    }
    get getUserCategory() {
        return this.userCategory;
    }
}
exports.User = User;
