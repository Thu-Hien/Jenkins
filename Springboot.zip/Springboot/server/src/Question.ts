/**
 * Demo application WWM - Software Engineering 1 - WS 2016/17
 * University of Applied Sciences Munich
 * author: SCS
 *
 * Model class for WWM questions.
 **/
 // export bedeutet, dass es nach außen sichtbar ist
export class Question {

// jeder Parameter wird in ein Attribut der Klasse umgesetzt, also müssen keine eigenen Attribute definiert werden
    constructor(private id: number, private question: string, private answerA: string, private answerB: string,
                private answerC: string, private answerD: string, private correctAnswer: number, private explanation: string) {
    }

    public get getQuestion() {
        return this.question;
    }

    public get getId() {
        return this.id;
    }

    public get getAnswerA() {
        return this.answerA;
    }

    public get getAnswerB() {
        return this.answerB;
    }

    public get getAnswerC() {
        return this.answerC;
    }

    public get getAnswerD() {
        return this.answerD;
    }

    public get getCorrectAnswer() {
        return this.correctAnswer;
    }

    public get getExplanation(){
      return this.explanation;
    }


}
