/**
 * Demo application WWM - Software Engineering 1 - WS 2016/17
 * University of Applied Sciences Munich
 * author: SCS
 *
 **/
 // Schnittstelle zwiwschen Serveranfrage und Datenbank, hier werden Datenbankabfragen abgesendet und Datenbanänderungen angestoßen

/// <reference path="DataSource.ts"/>  // verwendet DataSource
/// <reference path="Question.ts" />  // Fragen werden auch verwendet

import { DataSource } from './DataSource';
import { Question } from './Question';

export class QuestionDAO {

    private static ds : DataSource = DataSource.getInstance(); // einmalig erzeugtes Attribut

// alles statisch, da keine Objekte erzeugt werden sollen
public static getAllQuestions() : Promise<Array<Question>> {
  var query = "SELECT * FROM TB_QUESTIONS";
  return new Promise(function(resolve, reject){
    QuestionDAO.ds.getDatabase().all(query, function(err, rows){
      if(err){
        console.log("Failed");
        reject(err);
      }else{
        console.log("Success", rows);
        var questions : Array<Question> = new Array<Question>();

        for (var row of rows) {
          var question : Question = new Question(row['id'], row['question'], row['answerA'], row['answerB'], row['answerC'], row['answerD'], row['correctAnswer'], row['explanation']);
          questions.push(question);
        }

        resolve(questions);
      }
    });
  });
}

    public static createQuestion(newQuestion : Question) : Promise<number> {
      var insert : string = "INSERT INTO TB_QUESTIONS VALUES (NULL, '" + newQuestion.getQuestion
                             + "', '" + newQuestion.getAnswerA
                             + "', '" + newQuestion.getAnswerB
                             + "', '" + newQuestion.getAnswerC
                             + "', '" + newQuestion.getAnswerD
                             + "', '" + newQuestion.getCorrectAnswer
                             + "', '" + newQuestion.getExplanation +
                              "')";

      console.log(insert);
        return new Promise(function(resolve, reject) {
          QuestionDAO.ds.getDatabase().run(insert, function(err) {
            if(err) {
              console.log("Failed");
              reject (err);
            } else {
              console.log("Success " + this.lastID);
              resolve(this.lastID);
            }
          });
        });
    }

    // löschen einer Frage
        public static deleteQuestion(id : number) : Promise<number> {
          var query = "DELETE FROM TB_QUESTIONS WHERE id='" + id +"'";
          return new Promise(function(resolve, reject) {
            QuestionDAO.ds.getDatabase().run(query, function(err) {
              if(err) {
                console.log("Failed");
                reject (err);
              } else {
                console.log("Success" + id);
                resolve(id);
              }
            });
          });
        }

    public static getQuestionById(id : number, callback) {
      var query = "SELECT * FROM TB_QUESTIONS WHERE id='" + id +"'";
      this.ds.getDatabase().get(query, function(err, row) {
        var question = new Question(row['id'], row['question'], row['answerA'], row['answerB'], row['answerC'], row['answerD'], row['correctAnswer'], row['explanation']);
        callback(question);
      });
    }
}
