/**
 * Demo application WWM - Software Engineering 1 - WS 2016/17
 * University of Applied Sciences Munich
 * author: SCS
 *
 **/
 // Schnittstelle zwiwschen Serveranfrage und Datenbank, hier werden Datenbankabfragen abgesendet und Datenbanänderungen angestoßen

/// <reference path="DataSource.ts"/>  // verwendet DataSource
/// <reference path="User.ts" />  // Fragen werden auch verwendet

import { DataSource } from './DataSource';
import { User } from './User';

export class UserDAO {

    private static ds : DataSource = DataSource.getInstance(); // einmalig erzeugtes Attribut

// alles statisch, da keine Objekte erzeugt werden sollen
public static getAllUsers() : Promise<Array<User>> {
  var queryUsers = "SELECT * FROM TB_USERS";
  return new Promise(function(resolve, reject){
    UserDAO.ds.getDatabase().all(queryUsers, function(err, rows){
      if(err){
        console.log("Failed");
        reject(err);
      }else{
        console.log("Success", rows);
        var users : Array<User> = new Array<User>();

        for (var row of rows) {
          var user : User = new User(row['id'], row['user'], row['userCategory']);
          users.push(user);
        }

        resolve(users);
      }
    });
  });
}



// following function creates a new user
    public static createUser(newUser : User) : Promise<number> {
      var insert : string = "INSERT INTO TB_USERS VALUES (NULL, '" + newUser.getUser
                             + "', '" + newUser.getUserCategory + "')";
      console.log(insert);
        return new Promise(function(resolve, reject) {
          UserDAO.ds.getDatabase().run(insert, function(err) {
            if(err) {
              console.log("Failed");
              reject (err);
            } else {
              console.log("Success " + this.lastID);
              resolve(this.lastID);
            }
          });
        });
    }

//     // löschen einer Frage
//         public static deleteQuestion(id : number) : Promise<number> {
//           var query = "DELETE FROM TB_QUESTIONS WHERE id='" + id +"'";
//           return new Promise(function(resolve, reject) {
//             QuestionDAO.ds.getDatabase().run(query, function(err) {
//               if(err) {
//                 console.log("Failed");
//                 reject (err);
//               } else {
//                 console.log("Success" + id);
//                 resolve(id);
//               }
//             });
//           });
//         }
//
//     public static getQuestionById(id : number, callback) {
//       var query = "SELECT * FROM TB_QUESTIONS WHERE id='" + id +"'";
//       this.ds.getDatabase().get(query, function(err, row) {
//         var question = new Question(row['id'], row['question'], row['answerA'], row['answerB'], row['answerC'], row['answerD'], row['correctAnswer']);
//         callback(question);
//       });
//     }
}
