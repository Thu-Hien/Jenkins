/**
 * Demo application WWM - Software Engineering 1 - WS 2016/17
 * University of Applied Sciences Munich
 * author: SCS
 *
 **/
/// <reference path="../typings/express/express.d.ts" />
/// <reference path="../typings/body-parser/body-parser.d.ts" />
/// <reference path="Question.ts" />
/// <reference path="DataSource.ts"/>
/// <reference path="QuestionDAO.ts" />
/// <reference path="User.ts"/>
/// <reference path="UserDAO.ts" />

import * as express from 'express';
import * as bodyParser from 'body-parser';
import { Question } from './Question';
import { DataSource } from './DataSource';
import { QuestionDAO } from './QuestionDAO';
import { User } from './User';
import { UserDAO } from './UserDAO';

// create server app
const app = express();
const port:number = process.env.PORT || 8080;
const router = express.Router();

//CORS middleware
var allowCrossDomain = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
}

// config server app
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
app.use(allowCrossDomain);
app.use('/hps', router);

// start listening
app.listen(port);
console.log('http://127.0.0.1:' + port + '/hps');

// initialize database
DataSource.getInstance().initDatabase();

/** REST API **/

// test function
router.get('/', function (req, res) {
    res.json({"message": 'HPS server is running ...'});
});



// get question by id -> callback version
router.get('/question/:id', function (req, res) {
    var id = req.params.id;
    var callback = function(question) {
      var response = JSON.stringify(question);
      res.json(JSON.parse(response));
    }
    QuestionDAO.getQuestionById(id, callback);
});

// create a new question -> implemented using a Promise in QuestionDAO
router.put('/question/create', function(req, res) {
    var jsonQuestion = JSON.parse(JSON.stringify(req.body));
    var question = new Question(jsonQuestion['id'], jsonQuestion['question'], jsonQuestion['answerA'], jsonQuestion['answerB'],
                                jsonQuestion['answerC'], jsonQuestion['answerD'], jsonQuestion['correctAnswer'], jsonQuestion['explanation']);
    QuestionDAO.createQuestion(question).then((resolve)  => {
      res.json(JSON.parse(resolve.toString()));
    });
});

// Löschen der Frage mit der ID-> implemented using a Promise in QuestionDAO
router.delete('/question/delete/:id', function (req, res){
  var id = req.params.id;
  QuestionDAO.deleteQuestion(id).then((resolve) => {
    res.json(JSON.parse(resolve.toString()));
  });
});

// list all available questions -> promise Version
router.get('/listQuestions', function (req, res) {   // Anfrage und Rückgabe
  QuestionDAO.getAllQuestions().then((resolve) => {
    res.json(JSON.parse(JSON.stringify(resolve)));  // Aufruf ist eig. schon abgeschlossen und dann kommt noch response sobald callback erfoglreich ausgeführt wurde in QuestionDAO
  });
});

// The follwoing funcitons are all for the Usertable

// list all available users
router.get('/listUsers', function (req, res) {   // Anfrage und Rückgabe
  UserDAO.getAllUsers().then((resolve) => {
    res.json(JSON.parse(JSON.stringify(resolve)));  // Aufruf ist eig. schon abgeschlossen und dann kommt noch response sobald callback erfoglreich ausgeführt wurde in QuestionDAO
  });
});

// create a new user
router.put('/user/create', function(req, res) {
    var jsonUser = JSON.parse(JSON.stringify(req.body));
    var user = new User(jsonUser['id'], jsonUser['user'], jsonUser['userCategory']);
    UserDAO.createUser(user).then((resolve)  => {
      res.json(JSON.parse(resolve.toString()));
    });
});
