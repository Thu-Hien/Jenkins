/**
 * Demo application WWM - Software Engineering 1 - WS 2016/17
 * University of Applied Sciences Munich
 * author: SCS
 *
 * Model class for WWM questions.
 **/
 // export bedeutet, dass es nach außen sichtbar ist
export class User {

// jeder Parameter wird in ein Attribut der Klasse umgesetzt, also müssen keine eigenen Attribute definiert werden
    constructor(private id: number, private user: string, private userCategory: string) {
    }

    public get getUser() {
        return this.user;
    }

    public get getId() {
        return this.id;
    }

    public get getUserCategory() {
        return this.userCategory;
    }
}
