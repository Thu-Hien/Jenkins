/**
 * Demo application WWM - Software Engineering 1 - WS 2016/17
 * University of Applied Sciences Munich
 * author: SCS
 *
 **/
 /// <reference path="../typings/sqlite3/sqlite3.d.ts" />

 import {Database} from 'sqlite3';

 export class DataSource {
// Attribute _db = Variablenname,  :Database = Typ der Variable
   private _db : Database;
// neue DataSource wird angelegt, statisch
   private static _instance : DataSource = new DataSource();

// neue Datenbank wird angelegt MIT SQL und den Spaltendefinitionen
   private createQuestionTable : string = "CREATE TABLE TB_QUESTIONS (" +
                                          "id integer primary key, " +
                                          "question TEXT, " +
                                          "answerA TEXT, " +
                                          "answerB TEXT, " +
                                          "answerC TEXT, " +
                                          "answerD TEXT, " +
                                          "correctAnswer INT, " +
                                          "explanation TEXTnode " +
                                          ");";
   // zwei neue Datensätze werden in die Tablle eingefügt, NULL = Primary Key wird dann automatisch vergeben
   private insertQ1 : string = "INSERT INTO TB_QUESTIONS VALUES (NULL, 'In which town are you taken by GNR?', 'Sin City', 'Salt Lake City', 'Paradise City', 'Munich City', 3, 'blabla')";
   private insertQ2 : string = "INSERT INTO TB_QUESTIONS VALUES (NULL, 'Which song is not from AC/DC?', 'TNT', 'Highway to Hell', 'For Those About to Rock', 'Livin On a Prayer', 4, 'blabal')";
   private insertQ3 : string = "INSERT INTO TB_QUESTIONS VALUES (NULL, 'Was ist meine Liebingsfarbe?', 'Rot', 'Gruen', 'Lila', 'Gelb', 2, 'blabla')";

   // create new table for Users
   private createUserTable: string = "CREATE TABLE TB_USERS (" +
                                          "id integer primary key, " +
                                          "user TEXT, " +
                                          "userCategory TEXT " +
                                          ");";

  private insertU1 : string = "INSERT INTO TB_USERS VALUES (NULL, 'Emil', 'Lerner')";
  private insertU2 : string = "INSERT INTO TB_USERS VALUES (NULL, 'Timo', 'Lehrer')";

// Konstruktor wie in Java mit verschiedenen Parametern
   constructor() {
        if(DataSource._instance) {  // falls das Object Datenbank schon erzeugt wurde und jmd. noch eine erzeugen will (Konstruktoraufruf) dann kommt diese Fehlermeldung
            throw new Error("Not available for singletons!");
        }
        // else ->neue Datenbank soll erzeugt werden aus sqlite3 Package kommt das
        DataSource._instance = this;
        this._db = new Database(':memory:'); // :memory: sagt dass die Datenbank im Speicher erzeugt werden soll
    }
//  damit die Datenbank nur einmal angelegt wird und beim nächsten mal wird immer das einmalig statisch angelegte Object zurück gegeben, also die Instance
    public static getInstance() : DataSource {
        return DataSource._instance;
    }

    public getDatabase() : Database {
      return this._db;
    }

    // set up initial database structure containing some test values
    public initDatabase() { // Datenbank wird mit Beispieldaten befüllt
      var db = this._db; // Datenbank von oben wird in Variable gespeichert, muss hier abgespeichert werden weil Variablen überall sichtbar sind
      // bei der nächsten Methode "function" wäre die this._db sonst nicht sichtbar
      var tableQuestion = this.createQuestionTable; // Fragentabelle
      var q1 = this.insertQ1;
      var q2 = this.insertQ2;
      var q3 = this.insertQ3;
      var tableUser = this.createUserTable;
      var u1 = this.insertU1;
      var u2 = this.insertU2;

      db.serialize(function() {   // alles was jetzt gemacht wird soll seriell hintereinander ablaufen, eine Funktion wird als Parameter übergeben
        // die function ist hier anonym und wird danach nie wieder verwendet
        // create table
        db.run(tableQuestion); // eine sQL-Query wird bei run ausgeführt
        // add initial questions
        db.run(q1); // neue Frage wird angelegt
        db.run(q2);
        db.run(q3);

        db.run(tableUser);
        db.run(u1);
        db.run(u2);
      });
    }
 }
